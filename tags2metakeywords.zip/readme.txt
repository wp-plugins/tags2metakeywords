=== Plugin Name ===
Contributors: ThinkAgain
Donate link: http://www.thinkagain.cn/
Tags: meta keyword
Requires at least: 2.3
Tested up to: 2.6
Stable tag: 0.31

Add keyword based on tags, author, description and copyright info to meta area in html header. Requires Wordpress 2.3 or higher

== Description ==

This plugin provides ways to add keyword based on tags, author, description and copyright info to meta area in html header. Requires Wordpress 2.3 or above.


== Installation ==

Installation:
1. Upload tags2metakeywords folder to \wp-content\plugins\.
2. Activate plugin at the 'Plugin' option page in wordpress.

Upgrade:
1. Delete the previous tags2metakeywords.php under \wp-content\plugins\.
2. Upload tags2metakeywords folder to \wp-content\plugins\.
3. Activate plugin at the 'Plugin' option page in wordpress.

Uninstallation:
deactivate plugin at the 'Plugin' option page in wordpress.

== Frequently Asked Questions ==
None
== Screenshots ==
None